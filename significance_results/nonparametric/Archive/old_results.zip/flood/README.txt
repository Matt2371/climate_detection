FILE NAMING CONVENTION FOR RESULTS:

greater/lesser: type of one-tailed hypothesis test used
multi: multiple scenario analysis (e.g. count significant detection across multiple models for each year)
single: single scenario analysis (e.g. for each scenario, what is the first year of detection?)
win(num): size of rolling window used in analysis
total/byrcp/bygcm/bylulc: indicates by which scenario types results are sorted (total = all scenarios)

NOTES:
Total detection "counts" are relative, presented as a fraction of total relevant scenarios